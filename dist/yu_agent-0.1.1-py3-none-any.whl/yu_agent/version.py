"""版本信息"""

__version__ = "0.0.1"
__author__ = "Zhuoyang Wu"
__email__ = "wuzhuoyang252@gmail.com"
__description__ = "学习阶段的agent框架实现"